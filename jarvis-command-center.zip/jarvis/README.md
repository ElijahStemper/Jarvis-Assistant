# JARVIS Command Center

A production-minded starter for a personal AI command center. The UI and API are intentionally separated so credentials and integrations can be added without rewriting the interface.

## Architecture
- `apps/web`: Vite + React + TypeScript JARVIS HUD/interface.
- `apps/api`: Express + TypeScript API and integration boundary.
- `packages/shared`: reserved for shared types/utilities.

## Run locally
1. Install Node.js 20+.
2. From this folder run `npm install`.
3. Run `npm run dev`.
4. Open `http://localhost:5173`.

## Next integration layer
Implement provider adapters under `apps/api/src/integrations/` and route tool calls through a command orchestrator. Recommended order: Google Calendar, Gmail, GoHighLevel, YNAB, then an LLM/tool router and automations.

## Security rules
- Never put API keys in the React app.
- Keep secrets in environment variables or a secret manager.
- Use OAuth for Google services.
- Add auth before exposing the API outside localhost.
- Log tool calls, not secret values.
